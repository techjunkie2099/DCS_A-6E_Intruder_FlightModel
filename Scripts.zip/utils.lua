function startup_print(...)
    print(...)
end