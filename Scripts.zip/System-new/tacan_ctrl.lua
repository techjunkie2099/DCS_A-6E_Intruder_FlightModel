Tacan_ch_arg_hundreds	= 263
Tacan_ch_arg_tenths		= 264
Tacan_ch_arg_ones		= 265
Tacan_ch_arg_XY			= 266

need_to_be_closed = true